import os
import requests
import zipfile
import shutil
import subprocess
from github import Github

# Set your GitHub repository details
GITHUB_USERNAME = "benji77430"
GITHUB_REPOSITORY = "https://github.com/benji77430/fsociety.git"
GITHUB_TOKEN = "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"

# Set the URL of the version file in your GitHub repository
VERSION_FILE_URL = f"https://raw.githubusercontent.com/{GITHUB_USERNAME}/{GITHUB_REPOSITORY}/master/version.txt"

# Set the URL of the zip file containing the latest version of your app
APP_ZIP_URL = f"https://github.com/{GITHUB_USERNAME}/{GITHUB_REPOSITORY}/archive/refs/tags/latest.zip"

# Set the path to the current version of your app
APP_PATH = os.path.abspath(os.path.dirname(__file__))

# Set the path to the version file for your app
APP_VERSION_FILE = os.path.join(APP_PATH, "version.txt")

# Set the path to the zip file containing the latest version of your app
APP_ZIP_FILE = os.path.join(APP_PATH, "latest.zip")

# Set the path to the extracted app files
APP_EXTRACTED_PATH = os.path.join(APP_PATH, "extracted")

# Set the path to the app executable
APP_EXECUTABLE = os.path.join(APP_PATH, "keygen.py")

# Set the current version number of your app
APP_VERSION = ""

# Initialize the Github object
g = Github(GITHUB_TOKEN)

# Get the GitHub repository
repo = g.get_user().get_repo(GITHUB_REPOSITORY)

# Get the latest version number from the version file on GitHub
def get_latest_version():
    global APP_VERSION
    response = requests.get(VERSION_FILE_URL)
    if response.status_code == 200:
        APP_VERSION = response.text.strip()
        return APP_VERSION
    else:
        print(f"Error: Unable to retrieve version file from {VERSION_FILE_URL}")
        return None

# Download the latest version of your app from GitHub
def download_latest_version():
    response = requests.get(APP_ZIP_URL)
    if response.status_code == 200:
        with open(APP_ZIP_FILE, "wb") as f:
            f.write(response.content)
        return True
    else:
        print(f"Error: Unable to download app from {APP_ZIP_URL}")
        return False

# Extract the latest version of your app
def extract_latest_version():
    with zipfile.ZipFile(APP_ZIP_FILE, "r") as zip_ref:
        zip_ref.extractall(APP_EXTRACTED_PATH)
    return True

# Replace the current version of your app with the latest version
def replace_current_version():
    # Delete the current version of your app
    if os.path.exists(APP_PATH):
        shutil.rmtree(APP_PATH)

    # Rename the extracted app files to the current app path
    shutil.move(APP_EXTRACTED_PATH, APP_PATH)

    # Set the new app version number
    with open(APP_VERSION_FILE, "w") as f:
        f.write(APP_VERSION)

    # Set the new app executable path
    global APP_EXECUTABLE
    APP_EXECUTABLE = os.path.join(APP_PATH, "keygen.py")

# Check for updates and update if necessary
def check_for_updates():
    # Get the latest version number
    latest_version = get_latest_version()
    if latest_version:
        # Download the latest version
        if download_latest_version():
            # Extract the latest version
            if extract_latest_version():
                # Replace the current version
                replace_current_version()
                print(f"App updated to version {APP_VERSION}")
            else:
                print("Error: Unable to extract app files")
        else:
            print("Error: Unable to download app files")
    else:
        print("Error: Unable to retrieve version number")

# Check for updates and update if necessary
check_for_updates()

# Run your app
subprocess.Popen('keygen.py')